// ===== app.js (FINAL FIXED VERSION) =====

// 1. CONFIGURATION
const NFT_ADDRESS = "0x8bE01BD5d0D2eB74433fCB3b65A2A2A582dACc77";
const COIN_ADDRESS = "0x9f1b17B1C19be628e08EEa3f2D6B0D5bCb379645";
const STAKING_ADDRESS = "0x58Fd9BAf3973cf272976c6fAf7fd0cb9ceB031C7";

// ABIs
const NFT_ABI = [
    "function mintCopyright(string tokenURI) public returns (uint256)",
    "function mintCopyright(address to, string tokenURI) public returns (uint256)",
    "function balanceOf(address owner) view returns (uint256)",
    "function ownerOf(uint256 tokenId) view returns (address)",
    "function tokenURI(uint256 tokenId) view returns (string)",
    "function setApprovalForAll(address operator, bool approved) public",
    "function isApprovedForAll(address owner, address operator) view returns (bool)",
    "function getApproved(uint256 tokenId) view returns (address)",
    "function approve(address to, uint256 tokenId) public",
    "function totalSupply() view returns (uint256)",
    "function getCurrentTokenId() view returns (uint256)"
];

const COIN_ABI = [
    "function balanceOf(address account) view returns (uint256)"
];

const STAKING_ABI = [
    "function stakeNFT(uint256 tokenId) external",
    "function unstakeNFT(uint256 tokenId) external",
    "function claimRewards(uint256 tokenId) external",
    "function claimAllRewards() external",
    "function calculateRewards(uint256 tokenId) view returns (uint256)",
    "function getUserStakedNFTs(address user) view returns (uint256[])",
    "function getUserStakedCount(address user) view returns (uint256)",
    "function getTotalPendingRewards(address user) view returns (uint256)"
];

// Global State
let provider, signer, userAddress;
let nftContract, coinContract, stakingContract;

// 2. INITIALIZATION (Waits for page load)
window.addEventListener('DOMContentLoaded', async () => {
    console.log("DOM Loaded. Checking libraries...");

    // SAFETY CHECK: Ensure ethers.js loaded
    if (typeof ethers === 'undefined') {
        alert("CRITICAL ERROR: 'ethers' library not loaded. \n\nPlease check your internet connection.");
        return;
    }

    // Attach Event Listeners
    attachListener('connectWallet', connectWallet);
    attachListener('mintBtn', mintNFT);
    attachListener('approveAllBtn', approveAllNFTs);
    attachListener('stakeBtn', stakeNFT);
    attachListener('unstakeBtn', unstakeNFT);
    attachListener('claimBtn', claimRewards);
    attachListener('claimAllBtn', claimAllRewards);

    // Update UI Texts
    updateText('nftAddress', NFT_ADDRESS);
    updateText('coinAddress', COIN_ADDRESS);
    updateText('stakingAddress', STAKING_ADDRESS);

    // Auto-connect if already authorized
    if (window.ethereum) {
        // v5 provider
        const tempProvider = new ethers.providers.Web3Provider(window.ethereum);
        const accounts = await tempProvider.listAccounts();
        if (accounts.length > 0) {
            connectWallet();
        }
        
        window.ethereum.on('accountsChanged', () => window.location.reload());
        window.ethereum.on('chainChanged', () => window.location.reload());
    }
});

// Helper to attach events safely
function attachListener(id, func) {
    const el = document.getElementById(id);
    if (el) {
        el.addEventListener('click', func);
    } else {
        console.warn(`Button with ID '${id}' not found.`);
    }
}

// 3. CORE LOGIC

async function connectWallet() {
    if (!window.ethereum) return alert("Please install MetaMask!");

    try {
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        
        provider = new ethers.providers.Web3Provider(window.ethereum);
        signer = provider.getSigner();
        userAddress = await signer.getAddress();

        // Init Contracts
        nftContract = new ethers.Contract(NFT_ADDRESS, NFT_ABI, signer);
        coinContract = new ethers.Contract(COIN_ADDRESS, COIN_ABI, signer);
        stakingContract = new ethers.Contract(STAKING_ADDRESS, STAKING_ABI, signer);

        updateUI();
        alert("Wallet Connected: " + userAddress.substring(0,6) + "...");

    } catch (err) {
        console.error(err);
        alert("Connection Failed: " + (err.message || err));
    }
}

async function mintNFT() {
    if (!userAddress) return alert("Connect wallet first!");
    
    const input = document.getElementById('tokenURI');
    const tokenURI = input.value.trim();
    if (!tokenURI) return alert("Please enter a Token URI");

    try {
        setLoading('mintBtn', true, "Minting...");
        
        let tx;
        // Attempt minting with Gas Limit to prevent failures
        try {
            // Try standard signature
            if(nftContract["mintCopyright(string)"]) {
                tx = await nftContract["mintCopyright(string)"](tokenURI, { gasLimit: 600000 });
            } else {
                tx = await nftContract.mintCopyright(tokenURI, { gasLimit: 600000 });
            }
        } catch (err) {
            console.warn("Retrying with address param...", err);
            // Fallback signature
            if(nftContract["mintCopyright(address,string)"]) {
                tx = await nftContract["mintCopyright(address,string)"](userAddress, tokenURI, { gasLimit: 600000 });
            } else {
                tx = await nftContract.mintCopyright(userAddress, tokenURI, { gasLimit: 600000 });
            }
        }

        console.log("Tx sent:", tx.hash);
        await tx.wait();
        alert("✅ NFT Minted Successfully!");
        
        input.value = "";
        updateUI();

    } catch (err) {
        console.error("Mint Error:", err);
        alert("Mint Failed: " + (err.reason || err.message));
    } finally {
        setLoading('mintBtn', false, "Mint Copyright NFT");
    }
}

async function approveAllNFTs() {
    if (!nftContract) return alert("Connect wallet first");
    try {
        setLoading('approveAllBtn', true, "Approving...");
        const tx = await nftContract.setApprovalForAll(STAKING_ADDRESS, true);
        await tx.wait();
        alert("✅ Approval Set!");
        updateUI();
    } catch (err) {
        alert("Approval Failed: " + (err.reason || err.message));
    } finally {
        setLoading('approveAllBtn', false, "Approve All for Staking");
    }
}

async function stakeNFT() {
    const id = document.getElementById('stakeTokenId').value;
    if (!id) return alert("Enter Token ID");
    
    try {
        setLoading('stakeBtn', true, "Staking...");
        
        // Ownership Check
        const owner = await nftContract.ownerOf(id);
        if(owner.toLowerCase() !== userAddress.toLowerCase()) {
            throw new Error("You do not own this NFT");
        }

        const tx = await stakingContract.stakeNFT(id, { gasLimit: 500000 });
        await tx.wait();
        alert("✅ NFT Staked!");
        updateUI();
    } catch (err) {
        alert("Stake Failed: " + (err.reason || err.message));
    } finally {
        setLoading('stakeBtn', false, "Stake NFT");
    }
}

async function unstakeNFT() {
    const id = document.getElementById('unstakeTokenId').value;
    if (!id) return alert("Enter Token ID");

    try {
        setLoading('unstakeBtn', true, "Unstaking...");
        const tx = await stakingContract.unstakeNFT(id, { gasLimit: 500000 });
        await tx.wait();
        alert("✅ NFT Unstaked!");
        updateUI();
    } catch (err) {
        alert("Error: " + (err.reason || err.message));
    } finally {
        setLoading('unstakeBtn', false, "Unstake");
    }
}

async function claimRewards() {
    const id = document.getElementById('unstakeTokenId').value;
    if (!id) return alert("Enter Token ID");

    try {
        setLoading('claimBtn', true, "Claiming...");
        const tx = await stakingContract.claimRewards(id, { gasLimit: 500000 });
        await tx.wait();
        alert("✅ Rewards Claimed!");
        updateUI();
    } catch (err) {
        alert("Error: " + (err.reason || err.message));
    } finally {
        setLoading('claimBtn', false, "Claim Reward");
    }
}

async function claimAllRewards() {
    try {
        setLoading('claimAllBtn', true, "Claiming All...");
        const tx = await stakingContract.claimAllRewards({ gasLimit: 800000 });
        await tx.wait();
        alert("✅ All Rewards Claimed!");
        updateUI();
    } catch (err) {
        alert("Error: " + (err.reason || err.message));
    } finally {
        setLoading('claimAllBtn', false, "Claim All Rewards");
    }
}

// 4. UI UPDATERS

async function updateUI() {
    if (!userAddress) return;

    // Show Dashboard
    document.getElementById('walletInfo').style.display = 'block';
    updateText('walletAddress', userAddress.substring(0,6) + "..." + userAddress.substring(38));
    
    const net = await provider.getNetwork();
    updateText('networkInfo', `Connected to: ${net.name} (${net.chainId})`);
    
    const btn = document.getElementById('connectWallet');
    if (btn) { btn.innerText = "Connected"; btn.disabled = true; }

    // Update Balances
    try {
        const cpc = await coinContract.balanceOf(userAddress);
        updateText('cpcBalance', parseFloat(ethers.utils.formatEther(cpc)).toFixed(2));

        const nftBal = await nftContract.balanceOf(userAddress);
        updateText('nftBalance', nftBal.toString());

        const stakedCount = await stakingContract.getUserStakedCount(userAddress);
        updateText('stakedBalance', stakedCount.toString());

        const pending = await stakingContract.getTotalPendingRewards(userAddress);
        updateText('totalRewards', parseFloat(ethers.utils.formatEther(pending)).toFixed(4));
    } catch (e) { console.warn("Balance fetch error:", e); }

    // Load NFT List
    loadNFTList();
}

async function loadNFTList() {
    const list = document.getElementById('nftsList');
    if(!list) return;

    list.innerHTML = '<div class="loading">Loading tokens...</div>';
    let html = "";
    
    // Determine max ID to loop
    let maxId = 20;
    try {
        // Try totalSupply first
        const supply = await nftContract.totalSupply();
        maxId = supply.toNumber();
    } catch (e) {
        // Fallback to currentTokenId
        try {
            const curr = await nftContract.getCurrentTokenId();
            maxId = curr.toNumber();
        } catch (e2) {
            console.warn("Could not determine max ID, defaulting to 20");
        }
    }

    // Get Staked IDs
    let stakedIds = [];
    try {
        const stakedData = await stakingContract.getUserStakedNFTs(userAddress);
        stakedIds = stakedData.map(id => id.toString());
    } catch(e) {}

    const isApproved = await nftContract.isApprovedForAll(userAddress, STAKING_ADDRESS);

    // Loop through tokens
    for(let i = 1; i <= maxId; i++) {
        try {
            const owner = await nftContract.ownerOf(i);
            
            // If I own it OR if it is staked by me
            if (owner.toLowerCase() === userAddress.toLowerCase()) {
                const isStaked = stakedIds.includes(i.toString());
                const uri = await nftContract.tokenURI(i).catch(() => "No Metadata");

                html += `
                <div class="nft-card ${isStaked ? 'staked' : ''}">
                    <h3>Token #${i}</h3>
                    <p class="meta">${uri.substring(0, 30)}...</p>
                    <div class="status">${isStaked ? '🟢 STAKED' : '🔵 WALLET'}</div>
                    <div class="nft-actions">
                        ${!isStaked 
                            ? `<button onclick="fillStake(${i})">Select</button>` 
                            : `<button onclick="fillUnstake(${i})" class="secondary">Select</button>`
                        }
                    </div>
                </div>`;
            }
        } catch (e) {
            // Token likely doesn't exist or burnt, skip
        }
    }

    if(html === "") html = '<div class="no-nfts">No NFTs found.</div>';
    
    // Approval Warning
    if(!isApproved && html.includes("Select")) {
        html = `<div style="grid-column:1/-1; background:#331; padding:10px; border-radius:8px;">
                    ⚠️ You need to 'Approve All' before staking.
                </div>` + html;
    }

    list.innerHTML = html;
}

// Helpers
window.fillStake = (id) => { 
    document.getElementById('stakeTokenId').value = id; 
    window.scrollTo(0, document.getElementById('stake').offsetTop);
};
window.fillUnstake = (id) => { 
    document.getElementById('unstakeTokenId').value = id; 
    window.scrollTo(0, document.getElementById('stake').offsetTop);
};

function updateText(id, txt) {
    const el = document.getElementById(id);
    if(el) el.innerText = txt;
}

function setLoading(id, isLoading, txt) {
    const el = document.getElementById(id);
    if (!el) return;
    if (isLoading) {
        el.dataset.old = el.innerText;
        el.innerText = txt;
        el.disabled = true;
    } else {
        el.innerText = el.dataset.old || txt;
        el.disabled = false;
    }
}