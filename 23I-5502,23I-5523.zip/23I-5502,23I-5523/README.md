Copyright Staking Bank dApp - Blockchain-Powered Copyright Protection \& Rewards

&nbsp;Project Overview

Copyright Staking Bank is a decentralized application (dApp) that allows creators to protect their intellectual property through NFT-based copyright registration and earn rewards by staking their copyright assets. Built on Ethereum blockchain, this platform combines digital rights management with DeFi staking mechanics.



&nbsp;Theme: Digital Rights Management \& Creator Economy

This dApp addresses real-world challenges in copyright protection by leveraging blockchain technology to provide immutable proof of ownership and create new revenue streams for creators through staking mechanisms.



&nbsp;Features

Core Functionality

Copyright NFT Minting: Convert creative works into verifiable ERC-721 tokens



ERC-20 Reward System: Earn CopyrightCoin (CPC) tokens through staking



Advanced Staking System: Stake copyright NFTs to earn passive rewards



Real-time Dashboard: Monitor balances, staked NFTs, and pending rewards



Wallet Integration: MetaMask and Web3 wallet compatibility



Responsive Design: Optimized for desktop and mobile devices



Smart Contract Functions

CopyrightNFT Contract (ERC-721)



mintCopyright() - Create new copyright NFTs with metadata



stakeNFT() / unstakeNFT() - Manage staking status



getStakeStatus() - Check staking status



totalSupply() - Get total NFTs minted



CopyrightCoin Contract (ERC-20)



mintRewards() - Distribute staking rewards



calculateRewards() - Compute rewards based on staking duration



Fixed reward rate of 10 CPC tokens per day per NFT



CopyrightStaking Contract



stakeNFT() - Stake NFTs to earn rewards



unstakeNFT() - Unstake and automatically claim rewards



claimRewards() - Claim accumulated rewards for specific NFT



claimAllRewards() - Bulk reward claiming for all staked NFTs



calculateRewards() - View pending rewards



&nbsp;Technical Stack

Blockchain \& Smart Contracts

Solidity ^0.8.19



OpenZeppelin Contracts (ERC721, ERC20, ReentrancyGuard, Counters)



Ethereum Testnet (Sepolia)



Hardhat/Remix - Development \& Deployment



Frontend Technologies

HTML5 - Semantic structure and layout



CSS3 - Advanced styling with CSS variables and glass morphism



JavaScript ES6+ - Application logic and state management



Ethers.js v5.7.2 - Blockchain interaction and wallet connectivity



Font Awesome - Icon system



Design System

Cyberpunk Aesthetic - Neon colors and futuristic design



Glass Morphism - Transparent panels with backdrop blur



Custom SVG Cursor - Unique triangular pointer



Responsive Grid - Flexible layout for all devices



📁 Project Structure

text

MG3012\_FinalProject/

├── contracts/

│   ├── CopyrightNFT.sol

│   ├── CopyrightCoin.sol

│   └── CopyrightStaking.sol

├── frontend/

│   ├── index.html

│   ├── style.css

│   └── app.js

├── hardhat.config.js (or deployment config)

├── package.json

└── README.md

🔧 Installation \& Setup

Prerequisites

Node.js (v16 or higher)



MetaMask wallet browser extension



Git



Local Development

Clone Repository



bash

git clone <repository-url>

cd MG3012\_FinalProject

Install Dependencies



bash

npm install

Compile Contracts



bash

npx hardhat compile

Deploy to Testnet



bash

npx hardhat run scripts/deploy.js --network sepolia

Run Frontend



bash

cd frontend

\# Using Python HTTP server

python -m http.server 3000

\# Or using live-server

npx live-server

🌐 Deployment

Smart Contracts (Sepolia Testnet)

CopyrightNFT: 0x8bE01BD5d0D2eB74433fCB3b65A2A2A582dACc77



CopyrightCoin: 0x9f1b17B1C19be628e08EEa3f2D6B0D5bCb379645



CopyrightStaking: 0x58Fd9BAf3973cf272976c6fAf7fd0cb9ceB031C7



Frontend Deployment

Platform: GitHub Pages / Vercel / Netlify



Live URL: \[Your deployed URL here]



Requirements: Static hosting with HTTPS for Web3 compatibility



💡 How to Use

For Content Creators

Connect Wallet using MetaMask (Sepolia network)



Mint Copyright NFT by providing IPFS or metadata URI



Approve Staking Contract (one-time setup)



Stake NFT to start earning CPC rewards



Monitor Rewards in real-time dashboard



Claim Rewards individually or in bulk



Unstake NFT when needed (automatically claims rewards)



Reward System Mechanics

Base Rate: 10 CPC tokens per day per staked NFT



Real-time Calculation: Rewards accumulate every second



Flexible Claiming: Individual NFT rewards or bulk claims



Automatic Distribution: Rewards minted directly to wallet



&nbsp;Design \& User Experience

Visual Theme

Color Palette: Cyberpunk-inspired (cyan #00f3ff, purple #bc13fe, gold #ffd700)



Typography: Segoe UI with Consolas for data displays



Layout: Floating sidebar with main content area



Effects: Glass morphism, neon glows, and smooth animations



Interface Components

Custom Cursor: Triangular SVG pointer with cyberpunk styling



Glass Panels: Transparent cards with backdrop blur effects



Status Indicators: Color-coded NFT states (staked/unstaked)



Responsive Grid: Adaptive NFT gallery and statistics dashboard



&nbsp;Security Features

Reentrancy Protection: OpenZeppelin's ReentrancyGuard implementation



Access Control: Restricted functions to authorized contracts only



Input Validation: Comprehensive parameter checks in all functions



Safe Transfers: Secure NFT transfers between contracts and users



Gas Optimization: Efficient contract design with proper gas limits



&nbsp;Testing \& Verification

Test Coverage

✅ Contract deployment and initialization



✅ NFT minting with metadata



✅ Staking and unstaking functionality



✅ Reward calculation and distribution



✅ Edge cases and error handling



✅ Frontend-backend integration



Verification Commands

bash

\# Run tests

npx hardhat test



\# Check test coverage

npx hardhat coverage



\# Verify contracts on Etherscan

npx hardhat verify --network sepolia DEPLOYED\_CONTRACT\_ADDRESS

🎯 Evaluation Criteria Alignment

Criteria	Implementation Evidence

Smart Contract Design (4 marks)	Custom ERC-721/ERC-20 with staking logic, proper access control, 8+ functions

Frontend Integration (4 marks)	Full wallet connect, minting, staking, reward claiming with real-time updates

Creativity \& Theme (2 marks)	Unique copyright protection theme with cyberpunk aesthetics and real-world utility

Deployment \& Testing (3 marks)	Sepolia testnet deployment with comprehensive functionality and error handling

Documentation \& Presentation (7 marks)	Complete README, code comments, and demo-ready interface

🚀 Live Demo Features

During the 2-3 minute presentation, we will showcase:



Wallet Connection - Seamless MetaMask integration



NFT Minting - Create copyright token with metadata



Staking Process - Approve and stake NFT with one click



Reward System - Real-time reward tracking and claiming



User Experience - Responsive design and smooth interactions



&nbsp;Team Members

\[Laiba Imran] - \[23i-5502]



\[Rida Nadeem] - \[23i-5523]



📝 Submission Details

Course: MG3012 - Blockchain Technology for Business



Instructor: Dr. Usama Arshad



Deadline: 30 November 2025 (Sunday), 23:59 PKT



Semester: BSFT - 5th Semester (Fall 2025)



Submission Mode: Google Classroom 





